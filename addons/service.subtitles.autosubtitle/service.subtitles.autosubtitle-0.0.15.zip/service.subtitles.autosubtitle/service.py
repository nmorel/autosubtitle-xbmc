# -*- coding: utf-8 -*-

import os
import sys
import xbmc
import urllib
import urllib2
import xbmcaddon
import xbmcgui
import xbmcplugin
import json


__addon__ = xbmcaddon.Addon()
__author__ = __addon__.getAddonInfo('author')
__scriptid__ = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')
__language__ = __addon__.getLocalizedString

__cwd__ = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
__profile__ = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode("utf-8")
__resource__ = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'lib')).decode("utf-8")
__temp__ = xbmc.translatePath(os.path.join(__profile__, 'temp', '')).decode("utf-8")

sys.path.append(__resource__)

from utilities import log, normalizeString


def search(params):
    item = {
        'year': xbmc.getInfoLabel("VideoPlayer.Year"),
        'season': str(xbmc.getInfoLabel("VideoPlayer.Season")),
        'episode': str(xbmc.getInfoLabel("VideoPlayer.Episode")),
        'tvshow': normalizeString(xbmc.getInfoLabel("VideoPlayer.TVshowtitle")),
        'title': normalizeString(xbmc.getInfoLabel("VideoPlayer.OriginalTitle")),
        'file_original_path': urllib.unquote(xbmc.Player().getPlayingFile().decode('utf-8'))
    }

    if item['title'] == "":
        log(__scriptid__, "VideoPlayer.OriginalTitle not found")
        item['title'] = normalizeString(xbmc.getInfoLabel("VideoPlayer.Title"))  # no original title, get just Title

    if item['episode'].lower().find("s") > -1:  # Check if season is "Special"
        item['season'] = "0"  #
        item['episode'] = item['episode'][-1:]

    log(__scriptid__, "Search for [%s] by name" % (os.path.basename(item['file_original_path']),))

    url = __addon__.getSetting("AutoSubtitleUrl") + '/searchkodi'
    data = json.dumps(item)
    req = urllib2.Request(url, data, {'Content-Type': 'application/json'})
    http_response = urllib2.urlopen(req)
    response = json.load(http_response)

    if 'subtitles' in response and response['subtitles']:
        subtitles_list = response['subtitles']

        if 'downloadedFileName' in response and response['downloadedFileName']:
            listitem = xbmcgui.ListItem(label='Original', label2=response['downloadedFileName'])
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=listitem, isFolder=False)

        for it in subtitles_list:
            listitem = xbmcgui.ListItem(label=it["source"], label2=it["description"])

            url = "plugin://%s/?action=download&tvdbid=%s&season=%s&episode=%s&url=%s&file=%s" % (
                __scriptid__,
                it["tvdbid"],
                it["season"],
                it["episode"],
                it["url"],
                item['file_original_path']
            )

            headers = it["headers"]
            if headers:
                for key, value in headers.items():
                    url += "&%s=%s" % (key, value)

            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False)


def download(params):
    log(__scriptid__, "Params : [%s]" % params)
    data = {}
    # we write the values to a new dict and remove them from params
    del params["action"]
    data["tvdbid"] = params["tvdbid"]
    del params["tvdbid"]
    data["season"] = params["season"]
    del params["season"]
    data["episode"] = params["episode"]
    del params["episode"]
    data["url"] = params["url"]
    del params["url"]
    file = params["file"]
    del params["file"]

    # all the values left from params are considered headers
    data["headers"] = params

    log(__scriptid__, "Data : [%s]" % data)

    url = __addon__.getSetting("AutoSubtitleUrl") + '/download'
    req = urllib2.Request(url, json.dumps(data), {'Content-Type': 'application/json'})
    response = urllib2.urlopen(req)
    dest_file_name = json.load(response)['dest']

    dest_file = os.path.join(os.path.split(file)[0], dest_file_name)

    listitem = xbmcgui.ListItem(label=dest_file)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=dest_file, listitem=listitem, isFolder=False)


def get_params(string=""):
    param = []
    if string == "":
        paramstring = sys.argv[2]
    else:
        paramstring = string
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = get_params()

if params['action'] == 'search':
    log(__scriptid__, "action 'search' called")
    search(params)

elif params['action'] == 'download':
    log(__scriptid__, "action 'download' called with params : [%s]" % params)
    download(params)

elif params['action'] == 'manualsearch':
    log(__scriptid__, "action 'manualsearch' called")
    xbmc.executebuiltin(u'Notification(%s,%s,2000,%s)' % (__scriptname__,
                                                          __language__(32003),
                                                          os.path.join(__cwd__, "icon.png")))

xbmcplugin.endOfDirectory(int(sys.argv[1]))









